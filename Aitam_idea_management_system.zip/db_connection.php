<?PHP 
     $connect=mysqli_connect("localhost","root","","aitam_idea_management_system");
     #$connect=mysqli_connect("localhost","qp5uwu6wq87f","Girish@falcon5","aitam_idea_management_system");
   
?>